const { DISCORD_BOT_TOKEN: token, DISCORD_APPLICATION_ID: app, DISCORD_GUILD_ID: guild } = process.env;
if (!token || !app || !guild) {
  throw new Error("Set DISCORD_BOT_TOKEN, DISCORD_APPLICATION_ID, and DISCORD_GUILD_ID in your local environment.");
}

const commands = [{
  name: "bot",
  description: "Manage NOXUS bots",
  options: [
    { type: 1, name: "scan", description: "List bots and their roles" },
    { type: 1, name: "search", description: "Search for a bot by name or ID", options: [
      { type: 3, name: "query", description: "Bot name or ID", required: true }
    ]},
    { type: 1, name: "organize", description: "Assign a purpose/category role to a bot", options: [
      { type: 3, name: "bot_id", description: "Bot user ID", required: true },
      { type: 3, name: "category", description: "Purpose category (e.g. moderation, tickets)", required: true },
      { type: 3, name: "role_id", description: "Existing server role ID to assign", required: true }
    ]},
    { type: 1, name: "remove", description: "Kick a bot from this server", options: [
      { type: 3, name: "bot_id", description: "Bot user ID", required: true },
      { type: 5, name: "confirm", description: "Confirm that the bot should be kicked", required: true }
    ]}
  ]
}];

const response = await fetch(`https://discord.com/api/v10/applications/${app}/guilds/${guild}/commands`, {
  method: "PUT",
  headers: { Authorization: `Bot ${token}`, "Content-Type": "application/json" },
  body: JSON.stringify(commands),
});
if (!response.ok) throw new Error(`Command registration failed (${response.status}): ${await response.text()}`);
console.log("NOXUS slash commands registered successfully.");
