# NOXUS Bot Control

Cloudflare Worker-based Discord interaction endpoint for managing bots using slash commands only.

## Commands

- `/bot scan` — list bot accounts and their roles in the server.
- `/bot search query:<name-or-ID>` — search for a bot.
- `/bot organize bot_id:<ID> category:<purpose> role_id:<ID>` — assign an existing category role to a bot. It will not create roles automatically.
- `/bot remove bot_id:<ID> confirm:true` — kick a bot user from the server. This does not delete its Discord application or automatically remove all integration settings.

The interaction user must have the relevant permission: Manage Server for scan/search, Manage Roles for organize, or Kick Members for remove (Administrators are also allowed). The NOXUS bot account must independently have the needed server permissions. For role assignment, its highest role must be above the role being assigned. The command refuses to assign Administrator roles.

## Requirements

- Discord application and bot user
- Cloudflare Workers account
- Node.js/npm for registering slash commands
- Bot invited to your server with the minimum permissions needed

## Cloudflare setup

1. Deploy the repository as a Worker using `wrangler.toml`.
2. Add secrets in the repository folder. Run each command and paste the value when prompted:

   ```sh
   npx wrangler secret put DISCORD_PUBLIC_KEY
   npx wrangler secret put DISCORD_BOT_TOKEN
   ```

   `DISCORD_PUBLIC_KEY` is in Discord Developer Portal → General Information. `DISCORD_BOT_TOKEN` is in Developer Portal → Bot. Never commit or share the bot token.
3. Deploy with `npm install` then `npx wrangler deploy`.
4. Copy the deployed Worker URL and set it as Discord Developer Portal → General Information → Interactions Endpoint URL.
5. In Developer Portal → Bot, enable **Server Members Intent** if you want `/bot scan` and `/bot search` to read the server member list. Discord may reject member listing without this intent.

## Register slash commands

Set these variables in your local terminal (do not commit them):

- `DISCORD_BOT_TOKEN`
- `DISCORD_APPLICATION_ID`
- `DISCORD_GUILD_ID`

Then run:

```sh
npm install
npm run register
```

This registers commands to the chosen server for testing. Do not put these secrets in a public file or send them in chat.

## Deploy

```sh
npm install
npx wrangler deploy
```

## Notes

- The Worker uses Discord's signed interaction requests and verifies the Ed25519 signature before processing commands.
- Bot scanning paginates through member results instead of stopping after the first 1,000 members.
- `/bot organize` assigns an existing, non-managed role and refuses Administrator roles.
- `/bot remove` kicks the bot user only. If needed, review Server Settings → Integrations separately.
- Test with a low-risk bot first and grant only the permissions required for your use case.
