const API = "https://discord.com/api/v10";
const PERMS = {
  KICK_MEMBERS: 1n << 1n,
  ADMINISTRATOR: 1n << 3n,
  MANAGE_GUILD: 1n << 5n,
  MANAGE_ROLES: 1n << 28n,
};

export default {
  async fetch(request, env) {
    if (request.method === "GET") {
      return new Response("NOXUS Bot Control online", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }
    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    const signature = request.headers.get("x-signature-ed25519");
    const timestamp = request.headers.get("x-signature-timestamp");
    if (!signature || !timestamp || !env.DISCORD_PUBLIC_KEY) {
      return new Response("Unauthorized", { status: 401 });
    }

    const body = await request.text();
    try {
      const key = await crypto.subtle.importKey(
        "raw", hex(env.DISCORD_PUBLIC_KEY), { name: "Ed25519" }, false, ["verify"]
      );
      const valid = await crypto.subtle.verify(
        { name: "Ed25519" }, key, hex(signature),
        new TextEncoder().encode(timestamp + body)
      );
      if (!valid) return new Response("Invalid signature", { status: 401 });
    } catch {
      return new Response("Signature verification failed", { status: 401 });
    }

    let interaction;
    try { interaction = JSON.parse(body); }
    catch { return new Response("Invalid JSON", { status: 400 }); }

    if (interaction.type === 1) return json({ type: 1 });
    if (interaction.type !== 2 || interaction.data?.name !== "bot") {
      return reply("Unknown command.");
    }

    const sub = interaction.data.options?.[0];
    if (!sub?.name) return reply("Missing subcommand.");
    const opts = Object.fromEntries((sub.options || []).map(o => [o.name, o.value]));
    if (!interaction.guild_id || !interaction.member) {
      return reply("Use this command inside your Discord server.");
    }

    const userPermissions = BigInt(interaction.member.permissions || "0");
    const requiredPermission = sub.name === "organize"
      ? PERMS.MANAGE_ROLES
      : sub.name === "remove"
        ? PERMS.KICK_MEMBERS
        : PERMS.MANAGE_GUILD;
    if (!(userPermissions & PERMS.ADMINISTRATOR) &&
        !(userPermissions & requiredPermission)) {
      const needed = sub.name === "organize" ? "Manage Roles"
        : sub.name === "remove" ? "Kick Members" : "Manage Server";
      return reply(`You need **${needed}** permission to use this command.`);
    }
    if (!env.DISCORD_BOT_TOKEN) {
      return reply("Bot token is missing from Cloudflare Worker secrets.");
    }

    const guild = interaction.guild_id;
    const token = env.DISCORD_BOT_TOKEN;
    try {
      if (sub.name === "scan" || sub.name === "search") {
        const members = await getAllMembers(guild, token);
        let bots = members.filter(m => m.user?.bot);
        if (sub.name === "search") {
          const q = String(opts.query || "").trim().toLowerCase();
          if (!q) return reply("Enter a bot name or ID to search.");
          bots = bots.filter(m =>
            m.user.username.toLowerCase().includes(q) || m.user.id === q
          );
        }
        if (!bots.length) return reply("No matching bots found.");
        const lines = bots.slice(0, 25).map(m =>
          `• **${clean(m.user.username)}** — \`${m.user.id}\`\n` +
          `Roles: ${(m.roles || []).map(r => `<@&${r}>`).join(", ") || "None"}`
        );
        const extra = bots.length > 25 ? `\n…and ${bots.length - 25} more. Use /bot search to narrow the results.` : "";
        return reply(lines.join("\n") + extra);
      }

      if (sub.name === "organize") {
        const id = String(opts.bot_id || "");
        const roleId = String(opts.role_id || "");
        const category = clean(opts.category || "");
        if (!isSnowflake(id) || !isSnowflake(roleId)) {
          return reply("Invalid bot ID or role ID.");
        }
        const member = await api(`/guilds/${guild}/members/${id}`, token);
        if (!member.user?.bot) return reply("That account is not a bot.");

        const roles = await api(`/guilds/${guild}/roles`, token);
        const role = roles.find(r => r.id === roleId);
        if (!role || roleId === guild || role.managed) {
          return reply("That role cannot be assigned. Choose an existing, assignable server role.");
        }
        if ((BigInt(role.permissions || "0") & PERMS.ADMINISTRATOR) !== 0n) {
          return reply("For safety, NOXUS won't assign an Administrator role through this command.");
        }
        const me = await api("/users/@me", token);
        const botMember = await api(`/guilds/${guild}/members/${me.id}`, token);
        const botRoleIds = botMember.roles || [];
        const botHighest = roles.filter(r => botRoleIds.includes(r.id)).reduce((n, r) => Math.max(n, r.position), 0);
        if (role.position >= botHighest) {
          return reply("Move the NOXUS bot role above the category role in Server Settings → Roles, then try again.");
        }
        await api(`/guilds/${guild}/members/${id}/roles/${roleId}`, token, { method: "PUT" });
        return reply(`Organized **${clean(member.user.username)}** into **${category}** using <@&${roleId}>.`);
      }

      if (sub.name === "remove") {
        const id = String(opts.bot_id || "");
        if (!isSnowflake(id)) return reply("Invalid bot ID.");
        if (opts.confirm !== true) return reply("No action taken. Set confirm to true to kick the bot.");
        const member = await api(`/guilds/${guild}/members/${id}`, token);
        if (!member.user?.bot) return reply("That account is not a bot. Nothing was removed.");
        await api(`/guilds/${guild}/members/${id}`, token, { method: "DELETE" });
        return reply(`Kicked **${clean(member.user.username)}** from this server. This does not delete its Discord application; check Server Settings → Integrations separately if needed.`);
      }
      return reply("Unknown subcommand.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Discord API error";
      return reply(`Action failed: ${clean(message)}`);
    }
  },
};

async function getAllMembers(guild, token) {
  const all = [];
  let after = "";
  while (true) {
    const path = `/guilds/${guild}/members?limit=1000${after ? `&after=${after}` : ""}`;
    const page = await api(path, token);
    if (!Array.isArray(page)) throw new Error("Discord returned an unexpected member list.");
    all.push(...page);
    if (page.length < 1000) break;
    after = page[page.length - 1]?.user?.id;
    if (!after) throw new Error("Could not paginate the member list.");
  }
  return all;
}

async function api(path, token, init = {}) {
  const response = await fetch(API + path, {
    ...init,
    headers: { Authorization: `Bot ${token}`, "Content-Type": "application/json", ...init.headers },
  });
  if (response.status === 204) return null;
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!response.ok) {
    const message = typeof data === "object" ? data?.message : null;
    throw new Error(message || `Discord API returned HTTP ${response.status}`);
  }
  return data;
}

function reply(content) {
  return json({ type: 4, data: { content, allowed_mentions: { parse: [] } } });
}
function json(data) {
  return new Response(JSON.stringify(data), { headers: { "Content-Type": "application/json" } });
}
function hex(value) {
  if (!/^[0-9a-f]+$/i.test(value) || value.length % 2) throw new Error("Invalid hex");
  return new Uint8Array(value.match(/.{2}/g).map(byte => parseInt(byte, 16)));
}
function clean(value) {
  return String(value ?? "").replace(/[`*_~|<>@]/g, "").slice(0, 100);
}
function isSnowflake(value) {
  return /^\d{17,20}$/.test(value);
}
